# Mileage-Prediction
The following project aims to predict mileage per gallon(mps) using various technical specifications (features) as input to the regression algorithms
